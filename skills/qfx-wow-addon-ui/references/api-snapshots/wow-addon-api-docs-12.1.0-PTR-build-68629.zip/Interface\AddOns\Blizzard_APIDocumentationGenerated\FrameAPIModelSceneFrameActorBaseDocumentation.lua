local FrameAPIModelSceneFrameActorBase =
{
	Name = "FrameAPIModelSceneFrameActorBase",
	Type = "ScriptObject",
	Environment = "All",

	Functions =
	{
		{
			Name = "ClearModel",
			Type = "Function",

			Arguments =
			{
			},
		},
		{
			Name = "GetActiveBoundingBox",
			Type = "Function",

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "boxBottom", Type = "vector3", Mixin = "Vector3DMixin", Nilable = false },
				{ Name = "boxTop", Type = "vector3", Mixin = "Vector3DMixin", Nilable = false },
			},
		},
		{
			Name = "GetAlpha",
			Type = "Function",

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "alpha", Type = "number", Nilable = false },
			},
		},
		{
			Name = "GetAnimation",
			Type = "Function",

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "animation", Type = "AnimationDataEnum", Nilable = false },
			},
		},
		{
			Name = "GetAnimationBlendOperation",
			Type = "Function",

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "blendOp", Type = "ModelBlendOperation", Nilable = false },
			},
		},
		{
			Name = "GetAnimationVariation",
			Type = "Function",

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "variation", Type = "number", Nilable = false },
			},
		},
		{
			Name = "GetDesaturation",
			Type = "Function",

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "strength", Type = "number", Nilable = false },
			},
		},
		{
			Name = "GetMaxBoundingBox",
			Type = "Function",

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "boxBottom", Type = "vector3", Mixin = "Vector3DMixin", Nilable = false },
				{ Name = "boxTop", Type = "vector3", Mixin = "Vector3DMixin", Nilable = false },
			},
		},
		{
			Name = "GetModelFileID",
			Type = "Function",

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "file", Type = "fileID", Nilable = false },
			},
		},
		{
			Name = "GetModelPath",
			Type = "Function",

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "path", Type = "string", Nilable = false },
			},
		},
		{
			Name = "GetModelUnitGUID",
			Type = "Function",

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "guid", Type = "WOWGUID", Nilable = false },
			},
		},
		{
			Name = "GetParticleOverrideScale",
			Type = "Function",

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "scale", Type = "number", Nilable = true },
			},
		},
		{
			Name = "GetPitch",
			Type = "Function",

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "pitch", Type = "number", Nilable = false },
			},
		},
		{
			Name = "GetPosition",
			Type = "Function",

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "positionX", Type = "number", Nilable = false },
				{ Name = "positionY", Type = "number", Nilable = false },
				{ Name = "positionZ", Type = "number", Nilable = false },
			},
		},
		{
			Name = "GetRoll",
			Type = "Function",

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "roll", Type = "number", Nilable = false },
			},
		},
		{
			Name = "GetScale",
			Type = "Function",

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "scale", Type = "number", Nilable = false },
			},
		},
		{
			Name = "GetSpellVisualKit",
			Type = "Function",

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "spellVisualKitID", Type = "number", Nilable = false },
			},
		},
		{
			Name = "GetYaw",
			Type = "Function",

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "yaw", Type = "number", Nilable = false },
			},
		},
		{
			Name = "Hide",
			Type = "Function",

			Arguments =
			{
			},
		},
		{
			Name = "IsLoaded",
			Type = "Function",

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "isLoaded", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "IsPreferringModelCollisionBounds",
			Type = "Function",

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "preferringCollisionBounds", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "IsShown",
			Type = "Function",

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "isShown", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "IsUsingCenterForOrigin",
			Type = "Function",

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "x", Type = "bool", Nilable = false },
				{ Name = "y", Type = "bool", Nilable = false },
				{ Name = "z", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "IsVisible",
			Type = "Function",

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "isVisible", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "PlayAnimationKit",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "animationKit", Type = "number", Nilable = false },
				{ Name = "isLooping", Type = "bool", Nilable = false, Default = false },
			},
		},
		{
			Name = "SetAlpha",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "alpha", Type = "number", Nilable = false },
			},
		},
		{
			Name = "SetAnimation",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "animation", Type = "AnimationDataEnum", Nilable = false },
				{ Name = "variation", Type = "number", Nilable = true },
				{ Name = "animSpeed", Type = "number", Nilable = false, Default = 1 },
				{ Name = "animOffsetSeconds", Type = "number", Nilable = false, Default = 0 },
			},
		},
		{
			Name = "SetAnimationBlendOperation",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "blendOp", Type = "ModelBlendOperation", Nilable = false },
			},
		},
		{
			Name = "SetDesaturation",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "strength", Type = "number", Nilable = false },
			},
		},
		{
			Name = "SetGradientMask",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "gradientIndex0", Type = "number", Nilable = false },
				{ Name = "gradientIndex1", Type = "number", Nilable = false },
				{ Name = "gradientIndex2", Type = "number", Nilable = false },
				{ Name = "gradientIndex3", Type = "number", Nilable = false },
			},
		},
		{
			Name = "SetGradientMaskWithDyes",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "grad0DyeColorID", Type = "number", Nilable = true },
				{ Name = "grad1DyeColorID", Type = "number", Nilable = true },
				{ Name = "grad2DyeColorID", Type = "number", Nilable = true },
			},
		},
		{
			Name = "SetModelByCreatureDisplayID",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "creatureDisplayID", Type = "number", Nilable = false },
				{ Name = "useActivePlayerCustomizations", Type = "bool", Nilable = false, Default = false },
			},

			Returns =
			{
				{ Name = "success", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "SetModelByFileID",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "asset", Type = "FileAsset", Nilable = false },
				{ Name = "useMips", Type = "bool", Nilable = false, Default = false },
			},

			Returns =
			{
				{ Name = "success", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "SetModelByPath",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "asset", Type = "FileAsset", Nilable = false },
				{ Name = "useMips", Type = "bool", Nilable = false, Default = false },
			},

			Returns =
			{
				{ Name = "success", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "SetModelByUnit",
			Type = "Function",
			RequiresDeclassifiedUnitIdentity = true,
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "unit", Type = "UnitToken", Nilable = false },
				{ Name = "sheatheWeapons", Type = "bool", Nilable = false, Default = false },
				{ Name = "autoDress", Type = "bool", Nilable = false, Default = true },
				{ Name = "hideWeapons", Type = "bool", Nilable = false, Default = false },
				{ Name = "usePlayerNativeForm", Type = "bool", Nilable = false, Default = true },
				{ Name = "holdBowString", Type = "bool", Nilable = false, Default = false },
				{ Name = "customRaceID", Type = "number", Nilable = true },
			},

			Returns =
			{
				{ Name = "success", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "SetParticleOverrideScale",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "scale", Type = "number", Nilable = true },
			},
		},
		{
			Name = "SetPitch",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "pitch", Type = "number", Nilable = false },
			},
		},
		{
			Name = "SetPlayerModelFromGlues",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "characterIndex", Type = "number", Nilable = true },
				{ Name = "sheatheWeapons", Type = "bool", Nilable = false, Default = false },
				{ Name = "autoDress", Type = "bool", Nilable = false, Default = true },
				{ Name = "hideWeapons", Type = "bool", Nilable = false, Default = false },
				{ Name = "usePlayerNativeForm", Type = "bool", Nilable = false, Default = true },
				{ Name = "customRaceID", Type = "number", Nilable = true },
			},

			Returns =
			{
				{ Name = "success", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "SetPosition",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "positionX", Type = "number", Nilable = false },
				{ Name = "positionY", Type = "number", Nilable = false },
				{ Name = "positionZ", Type = "number", Nilable = false },
			},
		},
		{
			Name = "SetPreferModelCollisionBounds",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",
			Documentation = { "If true, will try to use the collision bounds of models for sizing and centering. Will fall back to default model bounds if set to False, or if collision bounds are unavailable." },

			Arguments =
			{
				{ Name = "preferCollisionBounds", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "SetRoll",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "roll", Type = "number", Nilable = false },
			},
		},
		{
			Name = "SetScale",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "scale", Type = "number", Nilable = false },
			},
		},
		{
			Name = "SetShown",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "show", Type = "bool", Nilable = false, Default = false },
			},
		},
		{
			Name = "SetSpellVisualKit",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "spellVisualKitID", Type = "number", Nilable = false, Default = 0 },
				{ Name = "oneShot", Type = "bool", Nilable = false, Default = false },
			},
		},
		{
			Name = "SetUseCenterForOrigin",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "x", Type = "bool", Nilable = false, Default = false },
				{ Name = "y", Type = "bool", Nilable = false, Default = false },
				{ Name = "z", Type = "bool", Nilable = false, Default = false },
			},
		},
		{
			Name = "SetYaw",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "yaw", Type = "number", Nilable = false },
			},
		},
		{
			Name = "Show",
			Type = "Function",

			Arguments =
			{
			},
		},
		{
			Name = "StopAnimationKit",
			Type = "Function",

			Arguments =
			{
			},
		},
		{
			Name = "TryOn",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "itemLinkOrItemModifiedAppearanceID", Type = "cstring", Nilable = false },
				{ Name = "handSlotName", Type = "cstring", Nilable = true },
				{ Name = "spellEnchantmentID", Type = "number", Nilable = false, Default = 0 },
			},

			Returns =
			{
				{ Name = "reason", Type = "ItemTryOnReason", Nilable = true },
			},
		},
	},

	Events =
	{
	},

	Tables =
	{
	},
	Predicates =
	{
	},
};

APIDocumentation:AddDocumentationTable(FrameAPIModelSceneFrameActorBase);