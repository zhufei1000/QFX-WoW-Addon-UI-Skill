local Pony =
{
	Name = "Pony",
	Type = "System",
	Namespace = "C_Pony",
	Environment = "All",
	Documentation = { "A pony is not simply a small horse., Time to pony up some documentation., See? Pony." },

	Functions =
	{
	},

	Events =
	{
	},

	Tables =
	{
	},
	Predicates =
	{
	},
};

APIDocumentation:AddDocumentationTable(Pony);