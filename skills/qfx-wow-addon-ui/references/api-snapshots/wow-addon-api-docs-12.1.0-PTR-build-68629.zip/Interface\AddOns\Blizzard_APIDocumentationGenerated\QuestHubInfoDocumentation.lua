local QuestHubInfo =
{
	Name = "QuestHubUI",
	Type = "System",
	Namespace = "C_QuestHub",
	Environment = "All",

	Functions =
	{
		{
			Name = "IsAreaPOICurrentlyRelatedToHub",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "areaPoiID", Type = "number", Nilable = false },
				{ Name = "hubAreaPoiID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "isRelated", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "IsQuestCurrentlyRelatedToHub",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
				{ Name = "hubAreaPoiID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "isRelated", Type = "bool", Nilable = false },
			},
		},
	},

	Events =
	{
	},

	Tables =
	{
	},
	Predicates =
	{
	},
};

APIDocumentation:AddDocumentationTable(QuestHubInfo);