local ScenarioInfo =
{
	Name = "ScenarioInfo",
	Type = "System",
	Namespace = "C_ScenarioInfo",
	Environment = "All",

	Functions =
	{
		{
			Name = "GetCriteriaInfo",
			Type = "Function",
			MayReturnNothing = true,
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "criteriaIndex", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "scenarioCriteriaInfo", Type = "ScenarioCriteriaInfo", Nilable = false },
			},
		},
		{
			Name = "GetCriteriaInfoByStep",
			Type = "Function",
			MayReturnNothing = true,
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "stepID", Type = "number", Nilable = false },
				{ Name = "criteriaIndex", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "scenarioCriteriaInfo", Type = "ScenarioCriteriaInfo", Nilable = false },
			},
		},
		{
			Name = "GetDisplayInfo",
			Type = "Function",
			MayReturnNothing = true,

			Returns =
			{
				{ Name = "info", Type = "ScenarioDisplayInfo", Nilable = false },
			},
		},
		{
			Name = "GetJailersTowerTypeString",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "runType", Type = "JailersTowerType", Nilable = false },
			},

			Returns =
			{
				{ Name = "typeString", Type = "cstring", Nilable = true },
			},
		},
		{
			Name = "GetScenarioIconInfo",
			Type = "Function",
			MayReturnNothing = true,
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "uiMapID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "scenarioInfos", Type = "table", InnerType = "ScenarioIconInfo", Nilable = false },
			},
		},
		{
			Name = "GetScenarioInfo",
			Type = "Function",
			MayReturnNothing = true,

			Returns =
			{
				{ Name = "scenarioInfo", Type = "ScenarioInformation", Nilable = false },
			},
		},
		{
			Name = "GetScenarioStepInfo",
			Type = "Function",
			MayReturnNothing = true,
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "scenarioStepID", Type = "number", Nilable = true },
			},

			Returns =
			{
				{ Name = "scenarioStepInfo", Type = "ScenarioStepInfo", Nilable = false },
			},
		},
		{
			Name = "GetTieredEntranceActiveSpells",
			Type = "Function",
			Documentation = { "Returns list of active challenge spells if inside a tiered entrance scenario" },

			Returns =
			{
				{ Name = "spellIDs", Type = "table", InnerType = "number", Nilable = true },
			},
		},
		{
			Name = "GetUnitCriteriaProgressValues",
			Type = "Function",
			MayReturnNothing = true,
			SecretWhenUnitIdentityRestricted = true,
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "unit", Type = "UnitToken", Nilable = false },
			},

			Returns =
			{
				{ Name = "actualValue", Type = "number", Nilable = false },
				{ Name = "percentValue", Type = "number", Nilable = false },
				{ Name = "percentValueString", Type = "string", Nilable = false },
			},
		},
		{
			Name = "IsTieredEntranceScenario",
			Type = "Function",

			Returns =
			{
				{ Name = "isTieredEntrance", Type = "bool", Nilable = false },
			},
		},
	},

	Events =
	{
		{
			Name = "JailersTowerLevelUpdate",
			Type = "Event",
			LiteralName = "JAILERS_TOWER_LEVEL_UPDATE",
			SynchronousEvent = true,
			Payload =
			{
				{ Name = "level", Type = "number", Nilable = false },
				{ Name = "type", Type = "JailersTowerType", Nilable = false },
			},
		},
		{
			Name = "ScenarioBonusObjectiveComplete",
			Type = "Event",
			LiteralName = "SCENARIO_BONUS_OBJECTIVE_COMPLETE",
			SynchronousEvent = true,
			Payload =
			{
				{ Name = "bonusObjectiveID", Type = "number", Nilable = false },
			},
		},
		{
			Name = "ScenarioBonusVisibilityUpdate",
			Type = "Event",
			LiteralName = "SCENARIO_BONUS_VISIBILITY_UPDATE",
			SynchronousEvent = true,
		},
		{
			Name = "ScenarioCompleted",
			Type = "Event",
			LiteralName = "SCENARIO_COMPLETED",
			SynchronousEvent = true,
			Payload =
			{
				{ Name = "questID", Type = "number", Nilable = true },
				{ Name = "xp", Type = "number", Nilable = true },
				{ Name = "money", Type = "number", Nilable = true },
			},
		},
		{
			Name = "ScenarioCriteriaShowStateUpdate",
			Type = "Event",
			LiteralName = "SCENARIO_CRITERIA_SHOW_STATE_UPDATE",
			SynchronousEvent = true,
			Payload =
			{
				{ Name = "show", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "ScenarioCriteriaUpdate",
			Type = "Event",
			LiteralName = "SCENARIO_CRITERIA_UPDATE",
			SynchronousEvent = true,
			Payload =
			{
				{ Name = "criteriaID", Type = "number", Nilable = false },
			},
		},
		{
			Name = "ScenarioPoiUpdate",
			Type = "Event",
			LiteralName = "SCENARIO_POI_UPDATE",
			SynchronousEvent = true,
		},
		{
			Name = "ScenarioSpellUpdate",
			Type = "Event",
			LiteralName = "SCENARIO_SPELL_UPDATE",
			SynchronousEvent = true,
		},
		{
			Name = "ScenarioUpdate",
			Type = "Event",
			LiteralName = "SCENARIO_UPDATE",
			SynchronousEvent = true,
			Payload =
			{
				{ Name = "newStep", Type = "bool", Nilable = true },
			},
		},
	},

	Tables =
	{
		{
			Name = "JailersTowerType",
			Type = "Enumeration",
			NumValues = 15,
			MinValue = 0,
			MaxValue = 14,
			Fields =
			{
				{ Name = "TwistingCorridors", Type = "JailersTowerType", EnumValue = 0 },
				{ Name = "SkoldusHalls", Type = "JailersTowerType", EnumValue = 1 },
				{ Name = "FractureChambers", Type = "JailersTowerType", EnumValue = 2 },
				{ Name = "Soulforges", Type = "JailersTowerType", EnumValue = 3 },
				{ Name = "Coldheart", Type = "JailersTowerType", EnumValue = 4 },
				{ Name = "Mortregar", Type = "JailersTowerType", EnumValue = 5 },
				{ Name = "UpperReaches", Type = "JailersTowerType", EnumValue = 6 },
				{ Name = "ArkobanHall", Type = "JailersTowerType", EnumValue = 7 },
				{ Name = "TormentChamberJaina", Type = "JailersTowerType", EnumValue = 8 },
				{ Name = "TormentChamberThrall", Type = "JailersTowerType", EnumValue = 9 },
				{ Name = "TormentChamberAnduin", Type = "JailersTowerType", EnumValue = 10 },
				{ Name = "AdamantVaults", Type = "JailersTowerType", EnumValue = 11 },
				{ Name = "ForgottenCatacombs", Type = "JailersTowerType", EnumValue = 12 },
				{ Name = "Ossuary", Type = "JailersTowerType", EnumValue = 13 },
				{ Name = "BossRush", Type = "JailersTowerType", EnumValue = 14 },
			},
		},
		{
			Name = "ScenarioCriteriaInfo",
			Type = "Structure",
			Fields =
			{
				{ Name = "description", Type = "string", Nilable = false },
				{ Name = "criteriaType", Type = "number", Nilable = false, Default = 0 },
				{ Name = "completed", Type = "bool", Nilable = false, Default = false },
				{ Name = "quantity", Type = "number", Nilable = false, Default = 0 },
				{ Name = "totalQuantity", Type = "number", Nilable = false, Default = 0 },
				{ Name = "flags", Type = "number", Nilable = false, Default = 0 },
				{ Name = "assetID", Type = "number", Nilable = false, Default = 0 },
				{ Name = "criteriaID", Type = "number", Nilable = false },
				{ Name = "duration", Type = "number", Nilable = false, Default = 0 },
				{ Name = "elapsed", Type = "number", Nilable = false, Default = 0 },
				{ Name = "failed", Type = "bool", Nilable = false, Default = false },
				{ Name = "isWeightedProgress", Type = "bool", Nilable = false, Default = false },
				{ Name = "isFormatted", Type = "bool", Nilable = false, Default = false },
				{ Name = "quantityString", Type = "string", Nilable = false },
			},
		},
		{
			Name = "ScenarioDisplayInfo",
			Type = "Structure",
			Fields =
			{
				{ Name = "themeColor", Type = "colorRGB", Mixin = "ColorMixin", Nilable = false },
			},
		},
		{
			Name = "ScenarioIconInfo",
			Type = "Structure",
			Fields =
			{
				{ Name = "x", Type = "number", Nilable = false },
				{ Name = "y", Type = "number", Nilable = false },
				{ Name = "atlas", Type = "textureAtlas", Nilable = false },
				{ Name = "description", Type = "cstring", Nilable = false },
			},
		},
		{
			Name = "ScenarioInformation",
			Type = "Structure",
			Fields =
			{
				{ Name = "name", Type = "string", Nilable = false },
				{ Name = "currentStage", Type = "number", Nilable = false },
				{ Name = "numStages", Type = "number", Nilable = false },
				{ Name = "flags", Type = "number", Nilable = false },
				{ Name = "isComplete", Type = "bool", Nilable = false },
				{ Name = "xp", Type = "number", Nilable = false },
				{ Name = "money", Type = "number", Nilable = false },
				{ Name = "type", Type = "number", Nilable = false },
				{ Name = "area", Type = "string", Nilable = false },
				{ Name = "uiTextureKit", Type = "textureKit", Nilable = false },
				{ Name = "scenarioID", Type = "number", Nilable = false },
			},
		},
		{
			Name = "ScenarioStepInfo",
			Type = "Structure",
			Fields =
			{
				{ Name = "title", Type = "string", Nilable = false },
				{ Name = "description", Type = "string", Nilable = false },
				{ Name = "numCriteria", Type = "number", Nilable = false },
				{ Name = "stepFailed", Type = "bool", Nilable = false },
				{ Name = "isBonusStep", Type = "bool", Nilable = false },
				{ Name = "isForCurrentStepOnly", Type = "bool", Nilable = false },
				{ Name = "shouldShowBonusObjective", Type = "bool", Nilable = false },
				{ Name = "spells", Type = "table", InnerType = "ScenarioStepSpellInfo", Nilable = false },
				{ Name = "weightedProgress", Type = "number", Nilable = true },
				{ Name = "rewardQuestID", Type = "number", Nilable = false },
				{ Name = "widgetSetID", Type = "number", Nilable = true },
				{ Name = "stepID", Type = "number", Nilable = false },
			},
		},
		{
			Name = "ScenarioStepSpellInfo",
			Type = "Structure",
			Fields =
			{
				{ Name = "spellID", Type = "number", Nilable = false },
				{ Name = "name", Type = "string", Nilable = false },
				{ Name = "icon", Type = "number", Nilable = false },
			},
		},
	},
	Predicates =
	{
	},
};

APIDocumentation:AddDocumentationTable(ScenarioInfo);