local DeathAlert =
{
	Name = "DeathAlert",
	Type = "System",
	Namespace = "C_DeathAlert",
	Environment = "All",

	Functions =
	{
	},

	Events =
	{
		{
			Name = "HardcoreDeaths",
			Type = "Event",
			LiteralName = "HARDCORE_DEATHS",
			SynchronousEvent = true,
			Payload =
			{
				{ Name = "memberName", Type = "cstring", Nilable = false },
			},
		},
	},

	Tables =
	{
	},
	Predicates =
	{
	},
};

APIDocumentation:AddDocumentationTable(DeathAlert);