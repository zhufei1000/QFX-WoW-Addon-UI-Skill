local AuctionHouseConstants =
{
	Tables =
	{
		{
			Name = "AuctionConstants",
			Type = "Constants",
			Values =
			{
				{ Name = "DEFAULT_AUCTION_PRICE_MULTIPLIER", Type = "number", Value = 1.5 },
			},
		},
	},
	Predicates =
	{
	},
};

APIDocumentation:AddDocumentationTable(AuctionHouseConstants);