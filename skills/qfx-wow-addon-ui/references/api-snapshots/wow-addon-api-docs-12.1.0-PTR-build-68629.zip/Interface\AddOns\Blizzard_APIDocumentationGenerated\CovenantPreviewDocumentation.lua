local CovenantPreview =
{
	Name = "CovenantPreview",
	Type = "System",
	Namespace = "C_CovenantPreview",
	Environment = "All",

	Functions =
	{
		{
			Name = "CloseFromUI",
			Type = "Function",
		},
		{
			Name = "GetCovenantInfoForPlayerChoiceResponseID",
			Type = "Function",
			MayReturnNothing = true,
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "playerChoiceResponseID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "previewInfo", Type = "CovenantPreviewInfo", Nilable = false },
			},
		},
	},

	Events =
	{
		{
			Name = "CovenantPreviewClose",
			Type = "Event",
			LiteralName = "COVENANT_PREVIEW_CLOSE",
			SynchronousEvent = true,
		},
		{
			Name = "CovenantPreviewOpen",
			Type = "Event",
			LiteralName = "COVENANT_PREVIEW_OPEN",
			SynchronousEvent = true,
			Payload =
			{
				{ Name = "previewInfo", Type = "CovenantPreviewInfo", Nilable = false },
			},
		},
	},

	Tables =
	{
		{
			Name = "CovenantAbilityInfo",
			Type = "Structure",
			Fields =
			{
				{ Name = "spellID", Type = "number", Nilable = false },
				{ Name = "type", Type = "CovenantAbilityType", Nilable = false },
			},
		},
		{
			Name = "CovenantFeatureInfo",
			Type = "Structure",
			Fields =
			{
				{ Name = "name", Type = "cstring", Nilable = false },
				{ Name = "description", Type = "cstring", Nilable = false },
				{ Name = "texture", Type = "number", Nilable = false },
			},
		},
		{
			Name = "CovenantPreviewInfo",
			Type = "Structure",
			Fields =
			{
				{ Name = "textureKit", Type = "textureKit", Nilable = false },
				{ Name = "transmogSetID", Type = "number", Nilable = false },
				{ Name = "mountID", Type = "number", Nilable = false },
				{ Name = "covenantName", Type = "string", Nilable = false },
				{ Name = "covenantZone", Type = "string", Nilable = false },
				{ Name = "description", Type = "string", Nilable = false },
				{ Name = "covenantCrest", Type = "textureAtlas", Nilable = false },
				{ Name = "covenantAbilities", Type = "table", InnerType = "CovenantAbilityInfo", Nilable = false },
				{ Name = "fromPlayerChoice", Type = "bool", Nilable = false },
				{ Name = "covenantSoulbinds", Type = "table", InnerType = "CovenantSoulbindInfo", Nilable = false },
				{ Name = "featureInfo", Type = "CovenantFeatureInfo", Nilable = false },
			},
		},
		{
			Name = "CovenantSoulbindInfo",
			Type = "Structure",
			Fields =
			{
				{ Name = "spellID", Type = "number", Nilable = false },
				{ Name = "uiTextureKit", Type = "textureKit", Nilable = false },
				{ Name = "name", Type = "cstring", Nilable = false },
				{ Name = "description", Type = "cstring", Nilable = false },
				{ Name = "sortOrder", Type = "number", Nilable = false },
			},
		},
	},
	Predicates =
	{
	},
};

APIDocumentation:AddDocumentationTable(CovenantPreview);