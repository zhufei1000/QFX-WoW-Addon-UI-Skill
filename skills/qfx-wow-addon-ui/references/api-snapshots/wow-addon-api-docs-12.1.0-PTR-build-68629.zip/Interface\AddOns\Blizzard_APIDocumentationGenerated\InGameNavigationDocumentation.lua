local InGameNavigation =
{
	Name = "InGameNavigation",
	Type = "System",
	Namespace = "C_Navigation",
	Environment = "All",

	Functions =
	{
		{
			Name = "GetDistance",
			Type = "Function",

			Returns =
			{
				{ Name = "distance", Type = "number", Nilable = false },
			},
		},
		{
			Name = "GetFrame",
			Type = "Function",

			Returns =
			{
				{ Name = "frame", Type = "ScriptRegion", Nilable = true },
			},
		},
		{
			Name = "GetNearestPartyMemberToken",
			Type = "Function",
			HasRestrictions = true,

			Returns =
			{
				{ Name = "unitToken", Type = "cstring", Nilable = false },
			},
		},
		{
			Name = "GetNextWaypointForMap",
			Type = "Function",
			MayReturnNothing = true,
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "uiMapID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "x", Type = "number", Nilable = false },
				{ Name = "y", Type = "number", Nilable = false },
				{ Name = "waypointDescription", Type = "string", Nilable = false },
			},
		},
		{
			Name = "GetTargetState",
			Type = "Function",

			Returns =
			{
				{ Name = "state", Type = "NavigationState", Nilable = false },
			},
		},
		{
			Name = "HasValidScreenPosition",
			Type = "Function",

			Returns =
			{
				{ Name = "hasValidScreenPosition", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "WasClampedToScreen",
			Type = "Function",

			Returns =
			{
				{ Name = "wasClamped", Type = "bool", Nilable = false },
			},
		},
	},

	Events =
	{
		{
			Name = "NavigationDestinationReached",
			Type = "Event",
			LiteralName = "NAVIGATION_DESTINATION_REACHED",
			SynchronousEvent = true,
			Payload =
			{
				{ Name = "isWaypoint", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "NavigationFrameCreated",
			Type = "Event",
			LiteralName = "NAVIGATION_FRAME_CREATED",
			SynchronousEvent = true,
			Payload =
			{
				{ Name = "region", Type = "ScriptRegion", Nilable = false },
			},
		},
		{
			Name = "NavigationFrameDestroyed",
			Type = "Event",
			LiteralName = "NAVIGATION_FRAME_DESTROYED",
			SynchronousEvent = true,
		},
	},

	Tables =
	{
		{
			Name = "NavigationState",
			Type = "Enumeration",
			NumValues = 4,
			MinValue = 0,
			MaxValue = 3,
			Fields =
			{
				{ Name = "Invalid", Type = "NavigationState", EnumValue = 0 },
				{ Name = "Occluded", Type = "NavigationState", EnumValue = 1 },
				{ Name = "InRange", Type = "NavigationState", EnumValue = 2 },
				{ Name = "Disabled", Type = "NavigationState", EnumValue = 3 },
			},
		},
	},
	Predicates =
	{
	},
};

APIDocumentation:AddDocumentationTable(InGameNavigation);