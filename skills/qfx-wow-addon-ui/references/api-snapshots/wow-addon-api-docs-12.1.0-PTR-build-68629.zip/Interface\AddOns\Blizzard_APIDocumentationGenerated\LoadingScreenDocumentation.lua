local LoadingScreen =
{
	Name = "LoadingScreen",
	Type = "System",
	Namespace = "C_LoadingScreen",
	Environment = "All",

	Functions =
	{
	},

	Events =
	{
		{
			Name = "LoadingScreenDisabled",
			Type = "Event",
			LiteralName = "LOADING_SCREEN_DISABLED",
			SynchronousEvent = true,
		},
		{
			Name = "LoadingScreenEnabled",
			Type = "Event",
			LiteralName = "LOADING_SCREEN_ENABLED",
			SynchronousEvent = true,
		},
	},

	Tables =
	{
	},
	Predicates =
	{
	},
};

APIDocumentation:AddDocumentationTable(LoadingScreen);