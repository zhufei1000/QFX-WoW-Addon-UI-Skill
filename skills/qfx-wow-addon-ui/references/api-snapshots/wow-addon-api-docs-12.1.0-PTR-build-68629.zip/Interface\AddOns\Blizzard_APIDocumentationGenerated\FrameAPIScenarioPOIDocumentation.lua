local FrameAPIScenarioPOI =
{
	Name = "FrameAPIScenarioPOI",
	Type = "ScriptObject",
	Environment = "All",

	Functions =
	{
		{
			Name = "GetScenarioTooltipText",
			Type = "Function",

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "tooltipText", Type = "cstring", Nilable = true },
			},
		},
		{
			Name = "UpdateMouseOverTooltip",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "x", Type = "number", Nilable = false },
				{ Name = "y", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "hasTooltip", Type = "bool", Nilable = false },
			},
		},
	},

	Events =
	{
	},

	Tables =
	{
	},
	Predicates =
	{
	},
};

APIDocumentation:AddDocumentationTable(FrameAPIScenarioPOI);