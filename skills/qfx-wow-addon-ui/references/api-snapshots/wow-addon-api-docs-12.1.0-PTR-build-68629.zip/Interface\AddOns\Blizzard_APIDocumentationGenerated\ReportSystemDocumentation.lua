local ReportSystem =
{
	Name = "ReportSystem",
	Type = "System",
	Namespace = "C_ReportSystem",
	Environment = "All",

	Functions =
	{
		{
			Name = "CanReportPlayer",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "playerLocation", Type = "PlayerLocation", Mixin = "PlayerLocationMixin", Nilable = false },
			},

			Returns =
			{
				{ Name = "canReport", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "CanReportPlayerForLanguage",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "playerLocation", Type = "PlayerLocation", Mixin = "PlayerLocationMixin", Nilable = false },
			},

			Returns =
			{
				{ Name = "canReport", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "GetMajorCategoriesForReportType",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "reportType", Type = "ReportType", Nilable = false },
			},

			Returns =
			{
				{ Name = "majorCategories", Type = "table", InnerType = "ReportMajorCategory", Nilable = false },
			},
		},
		{
			Name = "GetMajorCategoryString",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "majorCategory", Type = "ReportMajorCategory", Nilable = false },
			},

			Returns =
			{
				{ Name = "majorCategoryString", Type = "cstring", Nilable = false },
			},
		},
		{
			Name = "GetMinorCategoriesForReportTypeAndMajorCategory",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "reportType", Type = "ReportType", Nilable = false },
				{ Name = "majorCategory", Type = "ReportMajorCategory", Nilable = false },
			},

			Returns =
			{
				{ Name = "minorCategories", Type = "table", InnerType = "ReportMinorCategory", Nilable = false },
			},
		},
		{
			Name = "GetMinorCategoryString",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "minorCategory", Type = "ReportMinorCategory", Nilable = false },
			},

			Returns =
			{
				{ Name = "minorCategoryString", Type = "cstring", Nilable = false },
			},
		},
		{
			Name = "ReportServerLag",
			Type = "Function",
		},
		{
			Name = "ReportStuckInCombat",
			Type = "Function",
		},
		{
			Name = "RequiresScreenshotForReportType",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "reportType", Type = "ReportType", Nilable = false },
				{ Name = "majorCategory", Type = "ReportMajorCategory", Nilable = false },
			},

			Returns =
			{
				{ Name = "requiresScreenshot", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "SendReport",
			Type = "Function",
			HasRestrictions = true,
			SecretArguments = "AllowedWhenUntainted",
			Documentation = { "Not allowed to be called by addons" },

			Arguments =
			{
				{ Name = "reportInfo", Type = "ReportInfo", Mixin = "ReportInfoMixin", Nilable = false },
				{ Name = "playerLocation", Type = "PlayerLocation", Mixin = "PlayerLocationMixin", Nilable = true },
			},
		},
		{
			Name = "SetScreenshotPreviewTexture",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "textureObject", Type = "SimpleTexture", Nilable = false },
			},
		},
		{
			Name = "TakeReportScreenshot",
			Type = "Function",
		},
	},

	Events =
	{
		{
			Name = "ReportPlayerResult",
			Type = "Event",
			LiteralName = "REPORT_PLAYER_RESULT",
			SynchronousEvent = true,
			Payload =
			{
				{ Name = "result", Type = "SendReportResult", Nilable = false },
				{ Name = "reportType", Type = "ReportType", Nilable = false },
			},
		},
		{
			Name = "ReportScreenshotReady",
			Type = "Event",
			LiteralName = "REPORT_SCREENSHOT_READY",
			SynchronousEvent = true,
		},
	},

	Tables =
	{
	},
	Predicates =
	{
	},
};

APIDocumentation:AddDocumentationTable(ReportSystem);