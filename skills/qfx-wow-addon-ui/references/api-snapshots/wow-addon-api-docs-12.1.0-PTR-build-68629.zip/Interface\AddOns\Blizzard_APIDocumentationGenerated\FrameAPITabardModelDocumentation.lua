local FrameAPITabardModel =
{
	Name = "FrameAPITabardModel",
	Type = "ScriptObject",
	Environment = "All",

	Functions =
	{
		{
			Name = "GetLowerBackgroundFileName",
			Type = "Function",

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "file", Type = "fileID", Nilable = false },
			},
		},
		{
			Name = "GetLowerBorderFile",
			Type = "Function",

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "file", Type = "fileID", Nilable = false },
			},
		},
		{
			Name = "GetLowerEmblemFile",
			Type = "Function",

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "file", Type = "fileID", Nilable = false },
			},
		},
		{
			Name = "GetUpperBackgroundFileName",
			Type = "Function",

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "file", Type = "fileID", Nilable = false },
			},
		},
		{
			Name = "GetUpperBorderFile",
			Type = "Function",

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "file", Type = "fileID", Nilable = false },
			},
		},
		{
			Name = "GetUpperEmblemFile",
			Type = "Function",

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "file", Type = "fileID", Nilable = false },
			},
		},
	},

	Events =
	{
	},

	Tables =
	{
	},
	Predicates =
	{
	},
};

APIDocumentation:AddDocumentationTable(FrameAPITabardModel);