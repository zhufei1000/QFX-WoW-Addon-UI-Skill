local QuestLog =
{
	Name = "QuestLog",
	Type = "System",
	Namespace = "C_QuestLog",
	Environment = "All",

	Functions =
	{
		{
			Name = "AbandonQuest",
			Type = "Function",
		},
		{
			Name = "AddQuestWatch",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "wasWatched", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "AddWorldQuestWatch",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
				{ Name = "watchType", Type = "QuestWatchType", Nilable = true },
			},

			Returns =
			{
				{ Name = "wasWatched", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "CanAbandonQuest",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "canAbandon", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "DoesQuestAwardReputationWithFaction",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
				{ Name = "targetFactionID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "awardsReputation", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "GetAbandonQuest",
			Type = "Function",

			Returns =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},
		},
		{
			Name = "GetAbandonQuestItems",
			Type = "Function",
			MayReturnNothing = true,

			Returns =
			{
				{ Name = "itemIDs", Type = "table", InnerType = "number", Nilable = false },
			},
		},
		{
			Name = "GetActivePreyQuest",
			Type = "Function",
			MayReturnNothing = true,

			Returns =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},
		},
		{
			Name = "GetActiveThreatMaps",
			Type = "Function",
			MayReturnNothing = true,

			Returns =
			{
				{ Name = "uiMapIDs", Type = "table", InnerType = "number", Nilable = false },
			},
		},
		{
			Name = "GetAllCompletedQuestIDs",
			Type = "Function",

			Returns =
			{
				{ Name = "quests", Type = "table", InnerType = "number", Nilable = false },
			},
		},
		{
			Name = "GetBountiesForMapID",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "uiMapID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "bounties", Type = "table", InnerType = "BountyInfo", Nilable = true },
			},
		},
		{
			Name = "GetBountySetInfoForMapID",
			Type = "Function",
			MayReturnNothing = true,
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "uiMapID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "displayLocation", Type = "MapOverlayDisplayLocation", Nilable = false },
				{ Name = "lockQuestID", Type = "number", Nilable = false },
				{ Name = "bountySetID", Type = "number", Nilable = false },
				{ Name = "isActivitySet", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "GetDistanceSqToQuest",
			Type = "Function",
			MayReturnNothing = true,
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "distanceSq", Type = "number", Nilable = false },
				{ Name = "onContinent", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "GetHeaderIndexForQuest",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "index", Type = "luaIndex", Nilable = true },
			},
		},
		{
			Name = "GetInfo",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questLogIndex", Type = "luaIndex", Nilable = false },
			},

			Returns =
			{
				{ Name = "info", Type = "QuestInfo", Nilable = true },
			},
		},
		{
			Name = "GetLogIndexForQuestID",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",
			Documentation = { "Only returns a log index for actual quests, not headers" },

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "questLogIndex", Type = "luaIndex", Nilable = true },
			},
		},
		{
			Name = "GetMapForQuestPOIs",
			Type = "Function",

			Returns =
			{
				{ Name = "uiMapID", Type = "number", Nilable = false },
			},
		},
		{
			Name = "GetMaxNumQuests",
			Type = "Function",
			Documentation = { "This is the maximum number of quests a player can be on, including hidden quests, world quests, emissaries etc" },

			Returns =
			{
				{ Name = "maxNumQuests", Type = "number", Nilable = false },
			},
		},
		{
			Name = "GetMaxNumQuestsCanAccept",
			Type = "Function",
			Documentation = { "This is the maximum number of standard quests a player can accept. These are quests that are normally visible in the quest log." },

			Returns =
			{
				{ Name = "maxNumQuestsCanAccept", Type = "number", Nilable = false },
			},
		},
		{
			Name = "GetNextWaypoint",
			Type = "Function",
			MayReturnNothing = true,
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "mapID", Type = "number", Nilable = false },
				{ Name = "x", Type = "number", Nilable = false },
				{ Name = "y", Type = "number", Nilable = false },
			},
		},
		{
			Name = "GetNextWaypointForMap",
			Type = "Function",
			MayReturnNothing = true,
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
				{ Name = "uiMapID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "x", Type = "number", Nilable = false },
				{ Name = "y", Type = "number", Nilable = false },
			},
		},
		{
			Name = "GetNextWaypointText",
			Type = "Function",
			MayReturnNothing = true,
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "waypointText", Type = "string", Nilable = false },
			},
		},
		{
			Name = "GetNumQuestLogEntries",
			Type = "Function",

			Returns =
			{
				{ Name = "numShownEntries", Type = "number", Nilable = false },
				{ Name = "numQuests", Type = "number", Nilable = false },
			},
		},
		{
			Name = "GetNumQuestObjectives",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "leaderboardCount", Type = "number", Nilable = false },
			},
		},
		{
			Name = "GetNumQuestWatches",
			Type = "Function",

			Returns =
			{
				{ Name = "numQuestWatches", Type = "number", Nilable = false },
			},
		},
		{
			Name = "GetNumWorldQuestWatches",
			Type = "Function",

			Returns =
			{
				{ Name = "numQuestWatches", Type = "number", Nilable = false },
			},
		},
		{
			Name = "GetQuestAdditionalHighlights",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "uiMapID", Type = "number", Nilable = false },
				{ Name = "worldQuests", Type = "bool", Nilable = false },
				{ Name = "worldQuestsElite", Type = "bool", Nilable = false },
				{ Name = "dungeons", Type = "bool", Nilable = false },
				{ Name = "treasures", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "GetQuestDetailsTheme",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "theme", Type = "QuestTheme", Nilable = true },
			},
		},
		{
			Name = "GetQuestDifficultyLevel",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "level", Type = "number", Nilable = false },
			},
		},
		{
			Name = "GetQuestIDForLogIndex",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",
			Documentation = { "Only returns a questID for actual quests, not headers" },

			Arguments =
			{
				{ Name = "questLogIndex", Type = "luaIndex", Nilable = false },
			},

			Returns =
			{
				{ Name = "questID", Type = "number", Nilable = true },
			},
		},
		{
			Name = "GetQuestIDForQuestWatchIndex",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questWatchIndex", Type = "luaIndex", Nilable = false },
			},

			Returns =
			{
				{ Name = "questID", Type = "number", Nilable = true },
			},
		},
		{
			Name = "GetQuestIDForWorldQuestWatchIndex",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questWatchIndex", Type = "luaIndex", Nilable = false },
			},

			Returns =
			{
				{ Name = "questID", Type = "number", Nilable = true },
			},
		},
		{
			Name = "GetQuestLogMajorFactionReputationRewards",
			Type = "Function",
			MayReturnNothing = true,
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "reputationRewards", Type = "table", InnerType = "QuestRewardReputationInfo", Nilable = false },
			},
		},
		{
			Name = "GetQuestLogPortraitGiver",
			Type = "Function",
			MayReturnNothing = true,
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questLogIndex", Type = "luaIndex", Nilable = true },
			},

			Returns =
			{
				{ Name = "portraitGiver", Type = "number", Nilable = false },
				{ Name = "portraitGiverText", Type = "cstring", Nilable = false },
				{ Name = "portraitGiverName", Type = "cstring", Nilable = false },
				{ Name = "portraitGiverMount", Type = "number", Nilable = false },
				{ Name = "portraitGiverModelSceneID", Type = "number", Nilable = true },
			},
		},
		{
			Name = "GetQuestObjectives",
			Type = "Function",
			MayReturnNothing = true,
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "objectives", Type = "table", InnerType = "QuestObjectiveInfo", Nilable = false },
			},
		},
		{
			Name = "GetQuestRewardCurrencies",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "questRewardCurrencies", Type = "table", InnerType = "QuestRewardCurrencyInfo", Nilable = false },
			},
		},
		{
			Name = "GetQuestRewardCurrencyInfo",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
				{ Name = "currencyIndex", Type = "luaIndex", Nilable = false },
				{ Name = "isChoice", Type = "bool", Nilable = false },
			},

			Returns =
			{
				{ Name = "questRewardCurrencyInfo", Type = "QuestRewardCurrencyInfo", Nilable = true },
			},
		},
		{
			Name = "GetQuestTagInfo",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "info", Type = "QuestTagInfo", Nilable = true },
			},
		},
		{
			Name = "GetQuestType",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "questType", Type = "number", Nilable = true },
			},
		},
		{
			Name = "GetQuestWatchType",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "watchType", Type = "QuestWatchType", Nilable = true },
			},
		},
		{
			Name = "GetQuestsOnMap",
			Type = "Function",
			MayReturnNothing = true,
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "uiMapID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "quests", Type = "table", InnerType = "QuestPOIMapInfo", Nilable = false },
			},
		},
		{
			Name = "GetRequiredMoney",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",
			Documentation = { "Uses the selected quest if no questID is provided" },

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = true },
			},

			Returns =
			{
				{ Name = "requiredMoney", Type = "number", Nilable = false },
			},
		},
		{
			Name = "GetSelectedQuest",
			Type = "Function",

			Returns =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},
		},
		{
			Name = "GetSuggestedGroupSize",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "suggestedGroupSize", Type = "number", Nilable = false },
			},
		},
		{
			Name = "GetTimeAllowed",
			Type = "Function",
			MayReturnNothing = true,
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "totalTime", Type = "number", Nilable = false },
				{ Name = "elapsedTime", Type = "number", Nilable = false },
			},
		},
		{
			Name = "GetTitleForLogIndex",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",
			Documentation = { "Returns a valid title for anything that is in the quest log." },

			Arguments =
			{
				{ Name = "questLogIndex", Type = "luaIndex", Nilable = false },
			},

			Returns =
			{
				{ Name = "title", Type = "cstring", Nilable = true },
			},
		},
		{
			Name = "GetTitleForQuestID",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",
			Documentation = { "Only returns a valid title for quests, header titles cannot be discovered using this." },

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "title", Type = "cstring", Nilable = true },
			},
		},
		{
			Name = "GetZoneStoryInfo",
			Type = "Function",
			MayReturnNothing = true,
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "uiMapID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "achievementID", Type = "number", Nilable = false },
				{ Name = "storyMapID", Type = "number", Nilable = false },
			},
		},
		{
			Name = "HasActiveThreats",
			Type = "Function",

			Returns =
			{
				{ Name = "hasActiveThreats", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "IsAccountQuest",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "isAccountQuest", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "IsComplete",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "isComplete", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "IsFailed",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "isFailed", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "IsImportantQuest",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "isImportant", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "IsMetaQuest",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "isMeta", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "IsOnMap",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "onMap", Type = "bool", Nilable = false },
				{ Name = "hasLocalPOI", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "IsOnQuest",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "isOnQuest", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "IsPushableQuest",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "isPushable", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "IsQuestBounty",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "isBounty", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "IsQuestCalling",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "isCalling", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "IsQuestCriteriaForBounty",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
				{ Name = "bountyQuestID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "isCriteriaForBounty", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "IsQuestDisabledForSession",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "isDisabled", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "IsQuestFlaggedCompleted",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "isCompleted", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "IsQuestFlaggedCompletedOnAccount",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "isCompletedOnAccount", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "IsQuestFromContentPush",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "isFromContentPush", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "IsQuestInvasion",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "isInvasion", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "IsQuestReplayable",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "isReplayable", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "IsQuestReplayedRecently",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "recentlyReplayed", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "IsQuestTask",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "isTask", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "IsQuestTrivial",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "isTrivial", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "IsRepeatableQuest",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "isRepeatable", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "IsThreatQuest",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "isThreat", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "IsUnitOnQuest",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "unit", Type = "UnitToken", Nilable = false },
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "isOnQuest", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "IsWorldQuest",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "isWorldQuest", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "QuestCanHaveWarModeBonus",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",
			Documentation = { "Tests whether a quest is eligible for warmode bonuses (e.g. most world quests, some daily quests" },

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "hasBonus", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "QuestContainsFirstTimeRepBonusForPlayer",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "questContainsFirstTimeRepBonusForPlayer", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "QuestHasQuestSessionBonus",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "hasBonus", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "QuestHasWarModeBonus",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",
			Documentation = { "Tests whether a quest in the player's quest log that is eligible for warmode bonuses (see 'QuestCanHaveWarModeBOnus') has been completed in warmode (including accepting it)" },

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "hasBonus", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "QuestIgnoresAccountCompletedFiltering",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "questIgnoresAccountCompletedFiltering", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "ReadyForTurnIn",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "readyForTurnIn", Type = "bool", Nilable = true },
			},
		},
		{
			Name = "RemoveQuestWatch",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "wasRemoved", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "RemoveWorldQuestWatch",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "wasRemoved", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "RequestLoadQuestByID",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},
		},
		{
			Name = "SetAbandonQuest",
			Type = "Function",
		},
		{
			Name = "SetMapForQuestPOIs",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "uiMapID", Type = "number", Nilable = false },
			},
		},
		{
			Name = "SetSelectedQuest",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},
		},
		{
			Name = "ShouldDisplayTimeRemaining",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "displayTimeRemaining", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "ShouldShowQuestRewards",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},

			Returns =
			{
				{ Name = "shouldShow", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "SortQuestWatches",
			Type = "Function",
		},
		{
			Name = "UnitIsRelatedToActiveQuest",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "unit", Type = "UnitToken", Nilable = false },
			},

			Returns =
			{
				{ Name = "isRelatedToActiveQuest", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "UpdateCampaignHeaders",
			Type = "Function",
		},
	},

	Events =
	{
		{
			Name = "QuestAccepted",
			Type = "Event",
			LiteralName = "QUEST_ACCEPTED",
			SynchronousEvent = true,
			Payload =
			{
				{ Name = "questId", Type = "number", Nilable = false },
			},
		},
		{
			Name = "QuestAutocomplete",
			Type = "Event",
			LiteralName = "QUEST_AUTOCOMPLETE",
			SynchronousEvent = true,
			Payload =
			{
				{ Name = "questId", Type = "number", Nilable = false },
			},
		},
		{
			Name = "QuestComplete",
			Type = "Event",
			LiteralName = "QUEST_COMPLETE",
			SynchronousEvent = true,
		},
		{
			Name = "QuestDataLoadResult",
			Type = "Event",
			LiteralName = "QUEST_DATA_LOAD_RESULT",
			SynchronousEvent = true,
			Payload =
			{
				{ Name = "questID", Type = "number", Nilable = false },
				{ Name = "success", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "QuestDetail",
			Type = "Event",
			LiteralName = "QUEST_DETAIL",
			SynchronousEvent = true,
			Payload =
			{
				{ Name = "questStartItemID", Type = "number", Nilable = true },
			},
		},
		{
			Name = "QuestLogCriteriaUpdate",
			Type = "Event",
			LiteralName = "QUEST_LOG_CRITERIA_UPDATE",
			SynchronousEvent = true,
			Payload =
			{
				{ Name = "questID", Type = "number", Nilable = false },
				{ Name = "specificTreeID", Type = "number", Nilable = false },
				{ Name = "description", Type = "cstring", Nilable = false },
				{ Name = "numFulfilled", Type = "number", Nilable = false },
				{ Name = "numRequired", Type = "number", Nilable = false },
			},
		},
		{
			Name = "QuestLogUpdate",
			Type = "Event",
			LiteralName = "QUEST_LOG_UPDATE",
			UniqueEvent = true,
		},
		{
			Name = "QuestPoiUpdate",
			Type = "Event",
			LiteralName = "QUEST_POI_UPDATE",
			UniqueEvent = true,
		},
		{
			Name = "QuestRemoved",
			Type = "Event",
			LiteralName = "QUEST_REMOVED",
			SynchronousEvent = true,
			Payload =
			{
				{ Name = "questID", Type = "number", Nilable = false },
				{ Name = "wasReplayQuest", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "QuestTurnedIn",
			Type = "Event",
			LiteralName = "QUEST_TURNED_IN",
			SynchronousEvent = true,
			Payload =
			{
				{ Name = "questID", Type = "number", Nilable = false },
				{ Name = "xpReward", Type = "number", Nilable = false },
				{ Name = "moneyReward", Type = "number", Nilable = false },
			},
		},
		{
			Name = "QuestWatchListChanged",
			Type = "Event",
			LiteralName = "QUEST_WATCH_LIST_CHANGED",
			SynchronousEvent = true,
			UniqueEvent = true,
			Payload =
			{
				{ Name = "questID", Type = "number", Nilable = true },
				{ Name = "added", Type = "bool", Nilable = true },
			},
		},
		{
			Name = "QuestWatchUpdate",
			Type = "Event",
			LiteralName = "QUEST_WATCH_UPDATE",
			SynchronousEvent = true,
			Payload =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},
		},
		{
			Name = "QuestlineUpdate",
			Type = "Event",
			LiteralName = "QUESTLINE_UPDATE",
			SynchronousEvent = true,
			Payload =
			{
				{ Name = "requestRequired", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "TaskProgressUpdate",
			Type = "Event",
			LiteralName = "TASK_PROGRESS_UPDATE",
			SynchronousEvent = true,
		},
		{
			Name = "TreasurePickerCacheFlush",
			Type = "Event",
			LiteralName = "TREASURE_PICKER_CACHE_FLUSH",
			SynchronousEvent = true,
		},
		{
			Name = "WaypointUpdate",
			Type = "Event",
			LiteralName = "WAYPOINT_UPDATE",
			SynchronousEvent = true,
		},
		{
			Name = "WorldQuestCompletedBySpell",
			Type = "Event",
			LiteralName = "WORLD_QUEST_COMPLETED_BY_SPELL",
			SynchronousEvent = true,
			Payload =
			{
				{ Name = "questID", Type = "number", Nilable = false },
			},
		},
	},

	Tables =
	{
		{
			Name = "MapOverlayDisplayLocation",
			Type = "Enumeration",
			NumValues = 6,
			MinValue = 0,
			MaxValue = 5,
			Fields =
			{
				{ Name = "Default", Type = "MapOverlayDisplayLocation", EnumValue = 0 },
				{ Name = "BottomLeft", Type = "MapOverlayDisplayLocation", EnumValue = 1 },
				{ Name = "TopLeft", Type = "MapOverlayDisplayLocation", EnumValue = 2 },
				{ Name = "BottomRight", Type = "MapOverlayDisplayLocation", EnumValue = 3 },
				{ Name = "TopRight", Type = "MapOverlayDisplayLocation", EnumValue = 4 },
				{ Name = "Hidden", Type = "MapOverlayDisplayLocation", EnumValue = 5 },
			},
		},
		{
			Name = "QuestFrequency",
			Type = "Enumeration",
			NumValues = 4,
			MinValue = 0,
			MaxValue = 3,
			Fields =
			{
				{ Name = "Default", Type = "QuestFrequency", EnumValue = 0 },
				{ Name = "Daily", Type = "QuestFrequency", EnumValue = 1 },
				{ Name = "Weekly", Type = "QuestFrequency", EnumValue = 2 },
				{ Name = "ResetByScheduler", Type = "QuestFrequency", EnumValue = 3 },
			},
		},
		{
			Name = "QuestTag",
			Type = "Enumeration",
			NumValues = 12,
			MinValue = 1,
			MaxValue = 288,
			Fields =
			{
				{ Name = "Group", Type = "QuestTag", EnumValue = 1 },
				{ Name = "PvP", Type = "QuestTag", EnumValue = 41 },
				{ Name = "Raid", Type = "QuestTag", EnumValue = 62 },
				{ Name = "Dungeon", Type = "QuestTag", EnumValue = 81 },
				{ Name = "Legendary", Type = "QuestTag", EnumValue = 83 },
				{ Name = "Heroic", Type = "QuestTag", EnumValue = 85 },
				{ Name = "Raid10", Type = "QuestTag", EnumValue = 88 },
				{ Name = "Raid25", Type = "QuestTag", EnumValue = 89 },
				{ Name = "Scenario", Type = "QuestTag", EnumValue = 98 },
				{ Name = "Account", Type = "QuestTag", EnumValue = 102 },
				{ Name = "CombatAlly", Type = "QuestTag", EnumValue = 266 },
				{ Name = "Delve", Type = "QuestTag", EnumValue = 288 },
			},
		},
		{
			Name = "QuestWatchType",
			Type = "Enumeration",
			NumValues = 2,
			MinValue = 0,
			MaxValue = 1,
			Fields =
			{
				{ Name = "Automatic", Type = "QuestWatchType", EnumValue = 0 },
				{ Name = "Manual", Type = "QuestWatchType", EnumValue = 1 },
			},
		},
		{
			Name = "WorldQuestQuality",
			Type = "Enumeration",
			NumValues = 3,
			MinValue = 0,
			MaxValue = 2,
			Fields =
			{
				{ Name = "Common", Type = "WorldQuestQuality", EnumValue = 0 },
				{ Name = "Rare", Type = "WorldQuestQuality", EnumValue = 1 },
				{ Name = "Epic", Type = "WorldQuestQuality", EnumValue = 2 },
			},
		},
		{
			Name = "QuestInfo",
			Type = "Structure",
			Fields =
			{
				{ Name = "title", Type = "string", Nilable = false },
				{ Name = "questLogIndex", Type = "luaIndex", Nilable = false },
				{ Name = "questID", Type = "number", Nilable = false },
				{ Name = "campaignID", Type = "number", Nilable = true },
				{ Name = "level", Type = "number", Nilable = false },
				{ Name = "difficultyLevel", Type = "number", Nilable = false },
				{ Name = "suggestedGroup", Type = "number", Nilable = false },
				{ Name = "frequency", Type = "QuestFrequency", Nilable = true },
				{ Name = "isHeader", Type = "bool", Nilable = false },
				{ Name = "useMinimalHeader", Type = "bool", Nilable = false },
				{ Name = "sortAsNormalQuest", Type = "bool", Nilable = false },
				{ Name = "isCollapsed", Type = "bool", Nilable = false },
				{ Name = "startEvent", Type = "bool", Nilable = false },
				{ Name = "isTask", Type = "bool", Nilable = false },
				{ Name = "isBounty", Type = "bool", Nilable = false },
				{ Name = "isStory", Type = "bool", Nilable = false },
				{ Name = "isScaling", Type = "bool", Nilable = false },
				{ Name = "isOnMap", Type = "bool", Nilable = false },
				{ Name = "hasLocalPOI", Type = "bool", Nilable = false },
				{ Name = "isHidden", Type = "bool", Nilable = false },
				{ Name = "isAutoComplete", Type = "bool", Nilable = false },
				{ Name = "overridesSortOrder", Type = "bool", Nilable = false },
				{ Name = "readyForTranslation", Type = "bool", Nilable = false, Default = true },
				{ Name = "isInternalOnly", Type = "bool", Nilable = false },
				{ Name = "isAbandonOnDisable", Type = "bool", Nilable = false },
				{ Name = "headerSortKey", Type = "number", Nilable = true },
				{ Name = "questClassification", Type = "QuestClassification", Nilable = false },
			},
		},
		{
			Name = "QuestObjectiveInfo",
			Type = "Structure",
			Fields =
			{
				{ Name = "text", Type = "string", Nilable = false },
				{ Name = "type", Type = "string", Nilable = false },
				{ Name = "finished", Type = "bool", Nilable = false },
				{ Name = "numFulfilled", Type = "number", Nilable = false },
				{ Name = "numRequired", Type = "number", Nilable = false },
				{ Name = "objectiveType", Type = "QuestObjectiveType", Nilable = true },
			},
		},
		{
			Name = "QuestTagInfo",
			Type = "Structure",
			Fields =
			{
				{ Name = "tagName", Type = "cstring", Nilable = false },
				{ Name = "tagID", Type = "number", Nilable = false },
				{ Name = "worldQuestType", Type = "number", Nilable = true },
				{ Name = "quality", Type = "WorldQuestQuality", Nilable = true },
				{ Name = "tradeskillLineID", Type = "number", Nilable = true },
				{ Name = "isElite", Type = "bool", Nilable = true },
				{ Name = "displayExpiration", Type = "bool", Nilable = true },
			},
		},
		{
			Name = "QuestTheme",
			Type = "Structure",
			Fields =
			{
				{ Name = "background", Type = "textureAtlas", Nilable = false },
				{ Name = "seal", Type = "textureAtlas", Nilable = false },
				{ Name = "signature", Type = "cstring", Nilable = false },
				{ Name = "poiIcon", Type = "textureAtlas", Nilable = false },
				{ Name = "mapPinInfo", Type = "UIMapPinInfo", Nilable = true },
			},
		},
	},
	Predicates =
	{
	},
};

APIDocumentation:AddDocumentationTable(QuestLog);