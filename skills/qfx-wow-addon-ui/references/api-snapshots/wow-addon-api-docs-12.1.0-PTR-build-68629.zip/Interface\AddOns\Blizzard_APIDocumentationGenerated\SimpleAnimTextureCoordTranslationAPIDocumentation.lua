local SimpleAnimTextureCoordTranslationAPI =
{
	Name = "SimpleAnimTextureCoordTranslationAPI",
	Type = "ScriptObject",
	Environment = "All",

	Functions =
	{
		{
			Name = "GetOffset",
			Type = "Function",

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "offsetU", Type = "number", Nilable = false },
				{ Name = "offsetV", Type = "number", Nilable = false },
			},
		},
		{
			Name = "SetOffset",
			Type = "Function",
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "offsetU", Type = "number", Nilable = false },
				{ Name = "offsetV", Type = "number", Nilable = false },
			},
		},
	},

	Events =
	{
	},

	Tables =
	{
	},
	Predicates =
	{
	},
};

APIDocumentation:AddDocumentationTable(SimpleAnimTextureCoordTranslationAPI);